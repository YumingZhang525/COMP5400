package beast.app.draw;

public class TrackPoint {
    public int m_nX;
    public int m_nY, m_nCursor;

    public TrackPoint(int x, int y, int cursor) {
        m_nX = x;
        m_nY = y;
        m_nCursor = cursor;
    }
}
