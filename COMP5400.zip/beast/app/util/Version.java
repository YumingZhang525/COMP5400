package beast.app.util;

public abstract class Version {

    public abstract String getVersion();

    public abstract String getVersionString();

    public abstract String getDateString();

    public abstract String[] getCredits();

    public String getHTMLCredits() {
        String str = "";
        for (String s : getCredits()) {
            if (s.contains("@")) {
                str += "<a href=\"mailto:" + s + "\">" + s + "</a><br>";
            }
            if (s.contains("http")) {
                str += "<a href=\"" + s + "\">" + s + "</a><br>";
            } else {
                str += "<p>" + s + "</p>";
            }
        }
        return str;
    }
}
