package beast.app.beauti;

public interface BeautiDocListener {
    void docHasChanged() throws Exception;
}
