package beast.app.treeannotator;

public interface ContourMaker {

    ContourPath[] getContourPaths(double level);

}
