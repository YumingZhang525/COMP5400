package beast.core.util;

public interface Evaluator {
    double evaluate();
}
