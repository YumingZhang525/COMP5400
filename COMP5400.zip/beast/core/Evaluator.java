package beast.core;

public interface Evaluator {
    double evaluate();
}
