package beast.core;

import java.util.List;

public interface StateNodeInitialiser {

    /**
     * Called to set up start state. May be called multiple times. *
     */
    void initStateNodes();

    /**
     * @return list of StateNodes that are initialised
     *         This information is used to ensure StateNode are not initialised more than once.
     * @param stateNodes
     */
    void getInitialisedStateNodes(List<StateNode> stateNodes);
}
