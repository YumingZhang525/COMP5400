package beast.core;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * This is an annotation that can be used to both
 * + document a class at the top of the code and
 * + create user documentation for XML Beast files.
 * <p/>
 * The idea is to add @Description("bla bla bla")
 * just before class declarations of plug-ins. Applications
 * like DocMaker then can pick it up through introspection.
 * <p/>
 * To indicate that the description applies to all derived
 * classes, the isInheritable flag is set true by default.
 * This does not always apply, for instance when the description
 * contains text like "Should not be used directly, but by
 * implementations".
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface Description {

    /**
     * @return the description of the class
     */
    String value();

    /**
     * @return true to indicate this description applies to all its inherited classes as well, false otherwise
     */
    boolean isInheritable() default true;
}
