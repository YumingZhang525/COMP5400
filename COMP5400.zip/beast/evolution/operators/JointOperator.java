package beast.evolution.operators;

import java.util.ArrayList;
import java.util.List;

import beast.core.Description;
import beast.core.Input;
import beast.core.Operator;
import beast.core.StateNode;
import beast.core.util.Log;

@Description("Operator which allows multiple operators to be chained together."
        + " This is only correct when each operator acts on a different part"
        + " of the state.")
public class JointOperator extends Operator {
    
    final public Input<List<Operator>> operatorsInput = new Input<>(
            "operator",
            "List of operators to combine into one operation.",
            new ArrayList<>());

    @Override
    public void initAndValidate() { }
    
    @Override
    public double proposal() {
        double logHR = 0;
       
        for (Operator op : operatorsInput.get()) {

            logHR += op.proposal();
            
            // Stop here if the move is going to be rejected anyway
            if (logHR == Double.NEGATIVE_INFINITY)
                break;
            
            // Update calculation nodes as subsequent operators may depend on
            // state nodes made dirty by this operation.
            try {
                if (!op.listStateNodes().isEmpty())
                    op.listStateNodes().get(0).getState().checkCalculationNodesDirtiness();
            } catch (Exception ex) {
                Log.err(ex.getMessage());
            }
        }
        
        return logHR;
    }
    
    @Override
    public List<StateNode> listStateNodes() {
        List<StateNode> stateNodeList = new ArrayList<>();
        
        for (Operator op : operatorsInput.get())
            stateNodeList.addAll(op.listStateNodes());
        
        return stateNodeList;
    }
}
