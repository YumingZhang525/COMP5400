package beast.evolution.speciation;



import java.util.List;
import java.util.Random;

import beast.core.Description;
import beast.core.State;
import beast.evolution.tree.TreeDistribution;
import beast.evolution.tree.TreeInterface;

@Description("A likelihood function for speciation processes.")
abstract public class SpeciesTreeDistribution extends TreeDistribution {
//	SpeciesTreeDistribution extends TreeDistribution

    /**
     * Calculates the log likelihood of this set of coalescent intervals,
     * given a demographic model.
     *
     * @return the log likelihood
     */
    @Override
    public double calculateLogP() {
        // (Q2R): what if tree intervals?
        // (Q2R): always the same tree, no? so why pass in argument
        final TreeInterface tree = treeInput.get();
        logP = calculateTreeLogLikelihood(tree);
        return logP;
    } // calculateLogP


    /**
     * Generic likelihood calculation
     *
     * @param tree
     * @return log-likelihood of density
     */
    public abstract double calculateTreeLogLikelihood(TreeInterface tree);

    // ****************************************************************
    // Private and protected stuff
    // ****************************************************************


    /*****************************************/
    /** Distribution implementation follows **/
    /**
     * *************************************
     */
    @Override
    public List<String> getArguments() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<String> getConditions() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void sample(State state, Random random) {
        throw new UnsupportedOperationException("This should eventually sample a tree conditional on provided speciation model.");
    }
}