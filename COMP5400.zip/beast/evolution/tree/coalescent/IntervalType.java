package beast.evolution.tree.coalescent;
public enum IntervalType {

    /**
     * Denotes an interval at the end of which a new sample addition is
     * observed (i.e. the number of lineages is larger in the next interval).
     */
    SAMPLE("sample"),

    /**
     * Denotes an interval after which a coalescent event is observed
     * (i.e. the number of lineages is smaller in the next interval)
     */
    COALESCENT("coalescent"),

    /**
     * Denotes an interval at the end of which a migration event occurs.
     * This means that the colour of one lineage changes.
     */
    MIGRATION("migration"),

    /**
     * Denotes an interval at the end of which nothing is
     * observed (i.e. the number of lineages is the same in the next interval).
     */
    NOTHING("nothing");

    /**
     * private constructor.
     *
     * @param name the name of the interval type
     */
    private IntervalType(String name) {
        this.name = name;
    }

    @Override
	public String toString() {
        return name;
    }

    private final String name;
}