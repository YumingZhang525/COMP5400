package beast.evolution.alignment.distance;

import beast.core.Description;
import beast.evolution.alignment.Alignment;

/**
 * @author Andrew Rambaut
 * @author Korbinian Strimmer
 * @version $Id: JukesCantorDistanceMatrix.java,v 1.4 2005/05/24 20:25:56 rambaut Exp $
 */
@Description("compute jukes-cantor corrected distance")
public class JukesCantorDistance extends Distance.Base {


    /**
     * set the pattern source
     */
    @Override
    public void setPatterns(Alignment patterns) {
        super.setPatterns(patterns);

        final int stateCount = dataType.getStateCount();

        const1 = ((double) stateCount - 1) / stateCount;
        const2 = ((double) stateCount) / (stateCount - 1);
    }

    /**
     * Calculate a pairwise distance
     */
    @Override
    public double pairwiseDistance(int i, int j) {
        final double obsDist = super.pairwiseDistance(i, j);

        if (obsDist == 0.0) return 0.0;

        if (obsDist >= const1) {
            return MAX_DISTANCE;
        }

        final double expDist = -const1 * Math.log(1.0 - (const2 * obsDist));

        if (expDist < MAX_DISTANCE) {
            return expDist;
        } else {
            return MAX_DISTANCE;
        }
    }

    //
    // Private stuff
    //

    //used in correction formula
    private double const1, const2;
}
